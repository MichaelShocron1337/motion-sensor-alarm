# Alarm Service (SOAP / Java)

Minimal contract-first Java SOAP Alarm Service for the individual IoT assignment.

## Architecture for this assignment

There is no Integrated Service in this individual part. The ESP32 sends the same measurement in two forms:

- JSON/HTTP to the existing C# Measurement Service.
- SOAP/XML to this Java Alarm Service.

The Java Alarm Service does not automatically receive or intercept the request sent to the Measurement Service. The ESP32 C++ code therefore needs a second HTTP request for the SOAP service. That C++ addition is intentionally not included here so it can be implemented and understood separately.

## Network

The Alarm Service listens on all IPv4 interfaces on port 8093:

`http://0.0.0.0:8093/services/alarms`

From the same PC, the WSDL can be checked at:

`http://localhost:8093/services/alarms?wsdl`

From the ESP32, use the PC's current IPv4 address from `ipconfig`, for example:

`http://<YOUR-PC-IP>:8093/services/alarms`

Do not put `localhost` in the ESP32 code: on the ESP32, localhost means the ESP32 itself. The PC and ESP32 must be able to reach each other on the same network/hotspot, and Windows Firewall must allow inbound traffic to Java/port 8093.

The supplied WSDL remains the group contract and still contains its specified SOAP address. The runtime bind address above is only what makes the locally running implementation reachable from another device.

## Motion behavior

`EvaluateMeasurement` treats a measurement as motion when:

- `MeasurementType` is `Motion` (case-insensitive), and
- `Value` is numeric `1`.

When motion is detected, an `AlarmResult` is created. It preserves the sensor's `MeasuredAt` timestamp and adds `CreatedAt` for the time the Alarm Service created the alarm. The alarm is stored in an in-memory `List<AlarmResult>`.

The service also implements:

- `GetAlarmsByDeviceId`
- `GetAllAlarms`
- `InternalServiceFault` SOAP faults

## Build and run

Requirements: Java 17+ and Maven.

From the project directory:

```text
mvn clean compile
mvn exec:java
```

The Maven JAX-WS plugin generates the Java contract classes from `src/main/resources/wsdl/AlarmService.wsdl` during the build.

## Important

The C++/ESP32 SOAP sender still has to be added. Its SOAP XML must follow the WSDL exactly, including namespace, element names and SOAPAction.
