package se.group1.alarm;

import jakarta.xml.ws.Endpoint;

public class Main {
    public static void main(String[] args) {
        // Listen on every IPv4 network interface so another device on the same
        // network (for example the ESP32) can reach the service via the PC's
        // current IPv4 address from ipconfig.
        String bindAddress = "http://0.0.0.0:8093/services/alarms";

        Endpoint.publish(bindAddress, new AlarmServiceImpl());

        System.out.println("Alarm Service is listening on port 8093.");
        System.out.println("Local test: http://localhost:8093/services/alarms?wsdl");
        System.out.println("ESP32 target: http://<YOUR-PC-IP>:8093/services/alarms");
        System.out.println("Use the PC IPv4 address shown by ipconfig for <YOUR-PC-IP>.");
    }
}
