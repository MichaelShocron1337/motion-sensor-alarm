package se.group1.alarm;

import se.group1.alarm.generated.AlarmResult;
import java.util.ArrayList;
import java.util.List;

public class AlarmRepository {
    private final List<AlarmResult> alarms = new ArrayList<>();

    public synchronized void add(AlarmResult alarm) { alarms.add(alarm); }
    public synchronized List<AlarmResult> getAll() { return new ArrayList<>(alarms); }
}
