package se.group1.alarm;

import jakarta.jws.WebService;
import se.group1.alarm.generated.*;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.GregorianCalendar;

@WebService(
    serviceName = "AlarmService",
    portName = "AlarmServicePort",
    targetNamespace = "https://group1.system/alarm-service",
    endpointInterface = "se.group1.alarm.generated.AlarmServicePortType"
)
public class AlarmServiceImpl implements AlarmServicePortType {
    private final AlarmRepository repository = new AlarmRepository();

    @Override
    public EvaluateMeasurementResponse evaluateMeasurement(EvaluateMeasurementRequest request)
            throws InternalServiceFault_Exception {
        try {
            validate(request);
            EvaluateMeasurementResponse response = new EvaluateMeasurementResponse();

            // Motion sensor contract used by this project: Motion + value 1 = motion detected.
            boolean motionDetected = "Motion".equalsIgnoreCase(request.getMeasurementType())
                    && request.getValue().compareTo(BigDecimal.ONE) == 0;

            response.setAlarmCreated(motionDetected);
            if (!motionDetected) return response;

            AlarmResult alarm = new AlarmResult();
            alarm.setAlarmCreated("true"); // Contract defines this field as xs:string.
            alarm.setDeviceId(request.getDeviceId());
            alarm.setCreatedAt(now());
            alarm.setMessage("Motion detected");
            alarm.setMeasurementId(request.getMeasurementId());
            alarm.setMeasuredAt(request.getMeasuredAt());
            alarm.setValue(request.getValue());
            alarm.setMeasurementType(request.getMeasurementType());
            alarm.setUnit(request.getUnit());

            repository.add(alarm);
            response.setAlarm(alarm);
            return response;
        } catch (InternalServiceFault_Exception e) {
            throw e;
        } catch (Exception e) {
            throw fault("Could not evaluate measurement: " + e.getMessage());
        }
    }

    @Override
    public GetAlarmsByDeviceIdResponse getAlarmsByDeviceId(GetAlarmsByDeviceIdRequest request)
            throws InternalServiceFault_Exception {
        try {
            if (request == null || request.getDeviceId() == null || request.getDeviceId().isBlank())
                throw fault("DeviceId is required");

            GetAlarmsByDeviceIdResponse response = new GetAlarmsByDeviceIdResponse();
            for (AlarmResult alarm : repository.getAll()) {
                if (request.getDeviceId().equals(alarm.getDeviceId())) response.getAlarm().add(alarm);
            }
            return response;
        } catch (InternalServiceFault_Exception e) {
            throw e;
        } catch (Exception e) {
            throw fault("Could not get alarms by DeviceId: " + e.getMessage());
        }
    }

    @Override
    public GetAllAlarmsResponse getAllAlarms(GetAllAlarmsRequest request)
            throws InternalServiceFault_Exception {
        try {
            GetAllAlarmsResponse response = new GetAllAlarmsResponse();
            response.getAlarm().addAll(repository.getAll());
            return response;
        } catch (Exception e) {
            throw fault("Could not get alarms: " + e.getMessage());
        }
    }

    private void validate(EvaluateMeasurementRequest request) throws InternalServiceFault_Exception {
        if (request == null) throw fault("Request is required");
        if (request.getMeasurementId() == null || request.getMeasurementId().isBlank()) throw fault("MeasurementId is required");
        if (request.getDeviceId() == null || request.getDeviceId().isBlank()) throw fault("DeviceId is required");
        if (request.getMeasuredAt() == null) throw fault("MeasuredAt is required");
        if (request.getValue() == null) throw fault("Value is required");
        if (request.getMeasurementType() == null || request.getMeasurementType().isBlank()) throw fault("MeasurementType is required");
        if (request.getUnit() == null || request.getUnit().isBlank()) throw fault("Unit is required");
    }

    private InternalServiceFault_Exception fault(String message) {
        InternalServiceFault detail = new InternalServiceFault();
        detail.setMessage(message);
        return new InternalServiceFault_Exception(message, detail);
    }

    private XMLGregorianCalendar now() throws Exception {
        GregorianCalendar calendar = GregorianCalendar.from(java.time.ZonedDateTime.ofInstant(Instant.now(), java.time.ZoneOffset.UTC));
        return DatatypeFactory.newInstance().newXMLGregorianCalendar(calendar);
    }
}
